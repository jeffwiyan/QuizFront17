module.exports=[99230,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_list_page_actions_0e5d8af4.js.map