globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/cbd55ab9639e1e66.js",
    "static/chunks/4a2e6ca9bc162ffe.js",
    "static/chunks/6740f161f60c6ab5.js",
    "static/chunks/06525dfb60487280.js",
    "static/chunks/29141efe5227a7c5.js",
    "static/chunks/turbopack-7ff8511a8365ecc7.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];