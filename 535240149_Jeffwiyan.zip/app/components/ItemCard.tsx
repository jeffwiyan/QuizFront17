import Link from 'next/link';
import { useState } from 'react';

type Project = {
  id: string;
  title: string;
  description: string;
};

type ItemCardProps = {
  project: Project;
  onDelete: (id: string) => void;
};

export default function ItemCard({ project, onDelete }: ItemCardProps) {
  const [showConfirm, setShowConfirm] = useState(false);

  const handleDeleteClick = () => {
    setShowConfirm(true);
  };

  const confirmDelete = () => {
    onDelete(project.id);
    setShowConfirm(false);
  };

  const cancelDelete = () => {
    setShowConfirm(false);
  };

  return (
    <>
      <div className="card h-100 shadow-sm border-0">
        <div className="card-body d-flex flex-column">
          <div className="d-flex align-items-center mb-2">
            <i className="bi bi-folder-fill text-primary me-2 fs-5"></i>
            <h6 className="card-title mb-0 fw-bold">{project.title}</h6>
          </div>
          <p className="card-text text-muted small flex-grow-1">
            {project.description.length > 100
              ? `${project.description.substring(0, 100)}...`
              : project.description}
          </p>
          <div className="mt-auto">
            <div className="d-flex gap-2">
              <Link href={`/list/${project.id}`} className="btn btn-outline-primary btn-sm flex-fill">
                <i className="bi bi-eye me-1"></i>Detail
              </Link>
              <button
                className="btn btn-outline-danger btn-sm"
                onClick={handleDeleteClick}
                title="Hapus project"
              >
                <i className="bi bi-trash"></i>
              </button>
            </div>
          </div>
        </div>
      </div>

      {showConfirm && (
        <div className="modal fade show d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }} tabIndex={-1}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title text-danger">
                  <i className="bi bi-exclamation-triangle-fill me-2"></i>
                  Konfirmasi Hapus
                </h5>
                <button type="button" className="btn-close" onClick={cancelDelete}></button>
              </div>
              <div className="modal-body">
                <p className="mb-2">Apakah Anda yakin ingin menghapus project ini?</p>
                <div className="alert alert-warning">
                  <strong>{project.title}</strong>
                </div>
                <p className="text-muted small mb-0">Tindakan ini tidak dapat dibatalkan.</p>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={cancelDelete}>
                  Batal
                </button>
                <button type="button" className="btn btn-danger" onClick={confirmDelete}>
                  <i className="bi bi-trash me-2"></i>Hapus Project
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
