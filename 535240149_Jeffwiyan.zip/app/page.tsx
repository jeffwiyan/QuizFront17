import Image from "next/image";

export default function Home() {
  return (
    <div className="container py-5">
      <div className="row justify-content-center">
        <div className="col-lg-8">
          <div className="card shadow border-0">
            <div className="card-body text-center py-5">
              <div className="mb-4">
                <i className="bi bi-person-circle text-primary display-1 mb-3"></i>
              </div>
              <h1 className="display-4 fw-bold text-primary mb-3">Jeff Wiyan</h1>
              <div className="row justify-content-center mb-4">
                <div className="col-md-6">
                  <div className="card bg-light border-0">
                    <div className="card-body">
                      <h6 className="card-title text-muted mb-2">NIM</h6>
                      <h4 className="text-primary mb-0">535240149</h4>
                    </div>
                  </div>
                </div>
              </div>
              <div className="mb-4">
                <span className="badge bg-primary fs-6 px-4 py-2">
                  <i className="bi bi-folder-fill me-2"></i>Topik: Portfolio Profesional
                </span>
              </div>
              <p className="lead text-muted mb-4">
                Mini web application menggunakan Next.js dengan fitur manajemen project portfolio
              </p>
              <a href="/list" className="btn btn-primary btn-lg shadow">
                <i className="bi bi-list-ul me-2"></i>Kelola Portfolio Projects
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
