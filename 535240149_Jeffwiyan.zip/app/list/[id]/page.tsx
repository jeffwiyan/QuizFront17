'use client';

import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';

type Project = { id: string; title: string; description: string };

export default function DetailPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const [item, setItem] = useState<Project | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    try {
      const raw = localStorage.getItem('jeff_projects');
      if (!raw) {
        setIsLoading(false);
        return;
      }
      const list: Project[] = JSON.parse(raw);
      const found = list.find(p => p.id === params.id) || null;
      setItem(found);
    } catch (error) {
      console.error('Error loading project details:', error);
      setItem(null);
    } finally {
      setIsLoading(false);
    }
  }, [params.id]);

  if (isLoading) {
    return (
      <div className="container py-5">
        <div className="row justify-content-center">
          <div className="col-md-6">
            <div className="card shadow border-0">
              <div className="card-body text-center py-5">
                <div className="spinner-border text-primary mb-3" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
                <h5 className="card-title text-muted">Memuat Detail Project...</h5>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!item) {
    return (
      <div className="container py-5">
        <div className="row justify-content-center">
          <div className="col-md-6">
            <div className="card shadow border-0">
              <div className="card-body text-center py-5">
                <i className="bi bi-exclamation-triangle-fill text-warning display-1 mb-3"></i>
                <h4 className="card-title text-muted">Project Tidak Ditemukan</h4>
                <p className="card-text text-muted mb-4">
                  Project yang Anda cari tidak tersedia atau telah dihapus.
                </p>
                <button className="btn btn-primary" onClick={() => router.push('/list')} aria-label="Kembali ke halaman projects">
                  <i className="bi bi-arrow-left me-2"></i>Kembali ke Projects
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const shareUrl = typeof window !== 'undefined' ? `${window.location.origin}/list/${item.id}` : '';

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: item.title,
          text: item.description,
          url: shareUrl,
        });
      } catch (error) {
        console.log('Error sharing:', error);
      }
    } else {
      try {
        await navigator.clipboard.writeText(shareUrl);
        alert('Link berhasil disalin ke clipboard!');
      } catch (error) {
        alert('Tidak dapat membagikan. Link: ' + shareUrl);
      }
    }
  };

  return (
    <div className="container py-4">
      <div className="row justify-content-center">
        <div className="col-lg-8">
          <div className="card shadow border-0">
            <div className="card-header bg-primary text-white">
              <div className="d-flex align-items-center justify-content-between">
                <div className="d-flex align-items-center">
                  <i className="bi bi-folder-fill me-2 fs-4"></i>
                  <h4 className="mb-0">Detail Project</h4>
                </div>
                <span className="badge bg-light text-primary">ID: {item.id.slice(0, 8)}</span>
              </div>
            </div>
            <div className="card-body">
              <h2 className="card-title mb-4 fw-bold" role="heading" aria-level={1}>{item.title}</h2>
              <div className="mb-4">
                <h6 className="text-muted mb-3">
                  <i className="bi bi-file-text me-2"></i>Deskripsi Project
                </h6>
                <div className="bg-light p-3 rounded" role="region" aria-labelledby="description-heading">
                  <p className="mb-0">{item.description}</p>
                </div>
              </div>
              <div className="row mb-3">
                <div className="col-sm-6">
                  <div className="bg-light p-2 rounded text-center">
                    <small className="text-muted">Panjang Judul</small>
                    <div className="fw-bold">{item.title.length} karakter</div>
                  </div>
                </div>
                <div className="col-sm-6">
                  <div className="bg-light p-2 rounded text-center">
                    <small className="text-muted">Panjang Deskripsi</small>
                    <div className="fw-bold">{item.description.length} karakter</div>
                  </div>
                </div>
              </div>
              <div className="d-flex gap-2 flex-wrap">
                <button className="btn btn-outline-primary" onClick={() => router.push('/list')} aria-label="Kembali ke halaman daftar projects">
                  <i className="bi bi-arrow-left me-2"></i>Kembali ke Projects
                </button>
                <button className="btn btn-outline-secondary" onClick={handleShare} aria-label="Bagikan project ini">
                  <i className="bi bi-share me-2"></i>Bagikan
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
