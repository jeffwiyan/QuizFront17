'use client';

import { useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import ItemCard from '../components/ItemCard';

type Project = {
  id: string;
  title: string;
  description: string;
};

export default function ListPage() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<{title?: string; description?: string}>({});

  useEffect(() => {
    try {
      const raw = localStorage.getItem('jeff_projects');
      if (raw) {
        setProjects(JSON.parse(raw));
      }
    } catch (error) {
      console.error('Error loading projects from localStorage:', error);
      setProjects([]);
    }
  }, []);

  const saveToLocalStorage = (newProjects: Project[]) => {
    try {
      localStorage.setItem('jeff_projects', JSON.stringify(newProjects));
      setProjects(newProjects);
    } catch (error) {
      console.error('Error saving to localStorage:', error);
      alert('Gagal menyimpan data. Periksa penyimpanan browser Anda.');
    }
  };

  const validateForm = () => {
    const newErrors: {title?: string; description?: string} = {};

    if (!title.trim()) {
      newErrors.title = 'Judul project wajib diisi';
    } else if (title.trim().length < 3) {
      newErrors.title = 'Judul minimal 3 karakter';
    } else if (title.trim().length > 100) {
      newErrors.title = 'Judul maksimal 100 karakter';
    }

    if (!description.trim()) {
      newErrors.description = 'Deskripsi project wajib diisi';
    } else if (description.trim().length < 10) {
      newErrors.description = 'Deskripsi minimal 10 karakter';
    } else if (description.trim().length > 500) {
      newErrors.description = 'Deskripsi maksimal 500 karakter';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const addProject = async () => {
    if (!validateForm()) return;

    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 500));

    const newProject: Project = {
      id: uuidv4(),
      title: title.trim(),
      description: description.trim(),
    };
    const newProjects = [...projects, newProject];
    saveToLocalStorage(newProjects);
    setTitle('');
    setDescription('');
    setErrors({});
    setIsLoading(false);
  };

  const deleteProject = (id: string) => {
    const newProjects = projects.filter(p => p.id !== id);
    saveToLocalStorage(newProjects);
  };

  return (
    <div className="container py-4">
      <div className="row">
        <div className="col-12">
          <div className="d-flex justify-content-between align-items-center mb-4">
            <div>
              <h1 className="mb-0 text-primary">
                <i className="bi bi-folder-fill me-2"></i>Portfolio Projects
              </h1>
              <p className="text-muted mb-0">Kelola project portfolio Anda</p>
            </div>
            <span className="badge bg-primary fs-6 px-3 py-2">{projects.length} Projects</span>
          </div>
        </div>
      </div>

      {projects.length > 0 && (
        <div className="row mb-4">
          <div className="col-md-4">
            <div className="card bg-primary text-white border-0">
              <div className="card-body text-center">
                <i className="bi bi-folder-fill display-4 mb-2"></i>
                <h3 className="card-title mb-1">{projects.length}</h3>
                <p className="card-text mb-0">Total Projects</p>
              </div>
            </div>
          </div>
          <div className="col-md-4">
            <div className="card bg-success text-white border-0">
              <div className="card-body text-center">
                <i className="bi bi-check-circle-fill display-4 mb-2"></i>
                <h3 className="card-title mb-1">{projects.filter(p => p.title.length > 0).length}</h3>
                <p className="card-text mb-0">Active Projects</p>
              </div>
            </div>
          </div>
          <div className="col-md-4">
            <div className="card bg-info text-white border-0">
              <div className="card-body text-center">
                <i className="bi bi-bar-chart-line-fill display-4 mb-2"></i>
                <h3 className="card-title mb-1">
                  {projects.length > 0 ? Math.round(projects.reduce((acc, p) => acc + p.description.length, 0) / projects.length) : 0}
                </h3>
                <p className="card-text mb-0">Avg Description Length</p>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="card mb-4 shadow-sm">
        <div className="card-header bg-light">
          <h5 className="mb-0">
            <i className="bi bi-plus-circle-fill me-2"></i>Tambah Project Baru
          </h5>
        </div>
        <div className="card-body">
          <form onSubmit={(e) => { e.preventDefault(); addProject(); }}>
            <div className="row g-3">
              <div className="col-md-6">
                <label htmlFor="title" className="form-label fw-semibold">Judul Project</label>
                <input
                  type="text"
                  className={`form-control ${errors.title ? 'is-invalid' : title.trim() ? 'is-valid' : ''}`}
                  id="title"
                  placeholder="Masukkan judul project..."
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                />
                {errors.title && <div className="invalid-feedback">{errors.title}</div>}
                <div className="form-text">
                  {title.length}/100 karakter
                  <span className={`ms-2 ${title.length > 80 ? 'text-warning' : title.length > 95 ? 'text-danger' : 'text-muted'}`}>
                    {title.length > 95 ? '⚠️ Maksimal tercapai' : title.length > 80 ? '⚠️ Mendekati batas' : ''}
                  </span>
                </div>
              </div>
              <div className="col-md-6">
                <label htmlFor="description" className="form-label fw-semibold">Deskripsi</label>
                <textarea
                  className={`form-control ${errors.description ? 'is-invalid' : description.trim() ? 'is-valid' : ''}`}
                  id="description"
                  rows={3}
                  placeholder="Deskripsikan project Anda..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  required
                ></textarea>
                {errors.description && <div className="invalid-feedback">{errors.description}</div>}
                <div className="form-text">
                  {description.length}/500 karakter
                  <span className={`ms-2 ${description.length > 400 ? 'text-warning' : description.length > 480 ? 'text-danger' : 'text-muted'}`}>
                    {description.length > 480 ? '⚠️ Maksimal tercapai' : description.length > 400 ? '⚠️ Mendekati batas' : ''}
                  </span>
                </div>
              </div>
            </div>
            <div className="mt-3">
              <button
                type="submit"
                className="btn btn-primary"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <span className="spinner-border spinner-border-sm me-2" role="status"></span>
                    Menyimpan...
                  </>
                ) : (
                  <>
                    <i className="bi bi-plus-lg me-2"></i>Tambah Project
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>

      {projects.length === 0 ? (
        <div className="text-center py-5">
          <i className="bi bi-folder-x display-1 text-muted mb-3"></i>
          <h4 className="text-muted">Belum ada project</h4>
          <p className="text-muted">Tambahkan project pertama Anda di atas.</p>
        </div>
      ) : (
        <div className="row g-4">
          {projects.map((project) => (
            <div key={project.id} className="col-lg-4 col-md-6">
              <ItemCard project={project} onDelete={deleteProject} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
